#pragma once
void turnPD(int degree);
void Turn(double degree, float kP);
void TurnPR(double goal, double Kp);
void TurnPL(double goal, double Kp);
