#pragma once
void GG(int Ggoal , double KP , double KD);
void GG2(int Tgoal);