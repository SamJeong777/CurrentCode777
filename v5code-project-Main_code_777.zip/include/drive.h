#pragma once 
void setLeftDrive (vex::directionType type, int percent);
void setRightDrive (vex::directionType type, int percent);
void Mecanum();