#pragma once
void forwardP (double goal);
void backwardP (double goal);
int avENC1 ();