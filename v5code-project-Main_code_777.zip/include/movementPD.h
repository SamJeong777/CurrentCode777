#pragma once
void forwardPD(double goal);
void backwardPD(double goal);
void turnPDBAD(double goal);
void forwardInPD (double goal);
void SlideRight();
void SlideLeft();
void moving(int direction, int time,int takeType, int roller);
void SlideRight1(int time);
void SlideLeft1(int time);
void slide(double _pct_, float displacement, bool bl);
void MoveF ();
void my_Move(int _pct_, int displacement);