#pragma once
void Intake(int time);
void smolIntake();
void smolStop();
void largeIntake ();
void largeStop();
void smolOuttake();
void Rollers(int time);
void POOP(int time);
void POOP2();
void Poopstop ();