#pragma once 
void ZZ2(int Tgoal);
void ZZ(int Ggoal , double KP , double KD);